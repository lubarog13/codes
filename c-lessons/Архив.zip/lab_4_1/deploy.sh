make
./lab_4_1
