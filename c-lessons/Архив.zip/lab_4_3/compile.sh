make
./lab_4_3
