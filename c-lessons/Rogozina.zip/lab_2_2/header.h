#include <iostream>
#include <iomanip>
#include <string>
#include <limits>

const int N = 100;

using namespace std;
