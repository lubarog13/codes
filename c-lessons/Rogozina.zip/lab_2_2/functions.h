#include "header.h"

int inputInt(string message, int min, int max);
int inputInt(string message);
void assign(int *arr, int n);
void output(int *arr, int n);
void subArray(int *arr, int n, int k);