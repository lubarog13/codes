#include "header.h"

int inputInt(string message, int min);
char inputChar(string message);
string inputString(string message);

void addSymbols(string &input, string substring, char symbol, int count);
void outputString(string input);
