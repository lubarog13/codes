#include <iostream>
#include <iomanip>
#include <string>
#include <limits>
#include <fstream>
#include <cstddef>

using namespace std;

const int N = 100;
