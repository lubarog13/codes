#include <iostream>
#include <iomanip>
#include <string>
#include <limits>
#include <fstream>
#include <cstddef>
//#include <Windows.h>

using namespace std;

const int N = 100;
