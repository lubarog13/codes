package com.elegion.test.behancer.common;

/**
 * Created by Vladislav Falzan.
 */

public interface BaseView {

    void showRefresh();

    void hideRefresh();

    void showError();
}
