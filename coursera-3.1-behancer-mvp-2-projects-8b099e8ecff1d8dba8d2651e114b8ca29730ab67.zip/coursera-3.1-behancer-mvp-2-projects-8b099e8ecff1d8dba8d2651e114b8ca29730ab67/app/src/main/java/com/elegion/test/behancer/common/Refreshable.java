package com.elegion.test.behancer.common;

/**
 * @author Azret Magometov
 */
public interface Refreshable {
    void onRefreshData();
}
