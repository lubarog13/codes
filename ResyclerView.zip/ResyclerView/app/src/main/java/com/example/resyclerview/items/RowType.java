package com.example.resyclerview.items;

public interface RowType {
    int IMAGE_ROW_TYPE = 1;
    int DESCRIPTION_ROW_TYPE = 2;
}
