package com.elegion.test.behancer.common;

/**
 * @author Azret Magometov
 */
public interface RefreshOwner {
    void setRefreshState(boolean refreshing);
}